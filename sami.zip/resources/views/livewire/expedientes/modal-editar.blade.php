<div>
    <div class="modal-header">
        <h5 class="modal-title">Editar Expediente</h5>
    </div>
    <div class="modal-body">
        @livewire('expedientes.edit-expediente', ['expediente' => $expedientes])
    </div>
</div>
