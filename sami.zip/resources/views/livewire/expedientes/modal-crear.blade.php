<div>
    <div class="modal-header">
        <h5 class="modal-title">Crear Expediente</h5>
    </div>
    <div class="modal-body">
        @livewire('expedientes.create-expedientes')
    </div>
</div>
