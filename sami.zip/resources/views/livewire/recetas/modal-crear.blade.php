<div>
    <div class="modal-header">
        <h5 class="modal-title">Crear Receta</h5>
    </div>
    <div class="modal-body">
        @livewire('recetas.create-recetas', ['id_exp' => $id_exp])
    </div>
</div>
