<div>
    <div class="modal-header">
        <h5 class="modal-title">Editar Receta</h5>
    </div>
    <div class="modal-body">
        @livewire('recetas.edit-receta', ['receta' => $receta])
    </div>
</div>
