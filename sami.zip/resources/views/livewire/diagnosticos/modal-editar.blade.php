<div>
    <div class="modal-header">
        <h5 class="modal-title">Editar Diagnostico</h5>
    </div>
    <div class="modal-body">
        @livewire('diagnosticos.edit-diagnostico', ['diagnostico' => $diagnostico])
    </div>
</div>
