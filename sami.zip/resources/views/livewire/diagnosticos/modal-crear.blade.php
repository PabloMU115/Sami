<div>
    <div class="modal-header">
        <h5 class="modal-title">Crear Diagnostico</h5>
    </div>
    <div class="modal-body">
        @livewire('diagnosticos.create-diagnosticos', ['id_exp' => $id_exp])
    </div>
</div>
