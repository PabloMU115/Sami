<div>
    <div class="modal-header">
        <h5 class="modal-title">Editar Cita</h5>
    </div>
    <div class="modal-body">
        @livewire('citas.edit-cita', ['cita' => $cita])
    </div>
</div>
