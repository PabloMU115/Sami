@extends('adminlte::page')

@section('title', 'diagnosticos')

@section('content')
    @livewire('diagnosticos.show-diagnosticos')
@stop
