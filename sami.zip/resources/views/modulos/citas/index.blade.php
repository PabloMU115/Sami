@extends('adminlte::page')

@section('title', 'Citas')

@section('content')
    @livewire('citas.show-citas')
@stop
