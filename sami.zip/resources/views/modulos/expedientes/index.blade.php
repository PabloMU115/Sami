@extends('adminlte::page')

@section('title', 'Expedientes')

@section('content')
        @livewire('expedientes.show-expedientes')
@stop
