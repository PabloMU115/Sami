<div>
    <div class="modal-header">
        <h5 class="modal-title">Crear Expediente</h5>
    </div>
    <div class="modal-body">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('expedientes.create-expedientes')->html();
} elseif ($_instance->childHasBeenRendered('l508237752-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l508237752-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l508237752-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l508237752-0');
} else {
    $response = \Livewire\Livewire::mount('expedientes.create-expedientes');
    $html = $response->html();
    $_instance->logRenderedChild('l508237752-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php /**PATH C:\Users\User\Desktop\sami2\sami\resources\views/livewire/expedientes/modal-crear.blade.php ENDPATH**/ ?>