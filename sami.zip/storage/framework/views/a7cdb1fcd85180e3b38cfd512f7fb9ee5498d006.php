

<?php $__env->startSection('title', 'Recetas'); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('recetas.show-recetas')->html();
} elseif ($_instance->childHasBeenRendered('XsjtYQJ')) {
    $componentId = $_instance->getRenderedChildComponentId('XsjtYQJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('XsjtYQJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XsjtYQJ');
} else {
    $response = \Livewire\Livewire::mount('recetas.show-recetas');
    $html = $response->html();
    $_instance->logRenderedChild('XsjtYQJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\sami2\sami\resources\views/modulos/recetas/index.blade.php ENDPATH**/ ?>