

<?php $__env->startSection('title', 'diagnosticos'); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('diagnosticos.show-diagnosticos')->html();
} elseif ($_instance->childHasBeenRendered('YxR27n8')) {
    $componentId = $_instance->getRenderedChildComponentId('YxR27n8');
    $componentTag = $_instance->getRenderedChildComponentTagName('YxR27n8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YxR27n8');
} else {
    $response = \Livewire\Livewire::mount('diagnosticos.show-diagnosticos');
    $html = $response->html();
    $_instance->logRenderedChild('YxR27n8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\sami2\sami\resources\views/modulos/diagnosticos/index.blade.php ENDPATH**/ ?>