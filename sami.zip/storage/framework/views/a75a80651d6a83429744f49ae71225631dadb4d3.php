<div>
    <div class="modal-header">
        <h5 class="modal-title">Crear Cita</h5>
    </div>
    <div class="modal-body">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('citas.create-citas', ['id_exp' => $id_exp])->html();
} elseif ($_instance->childHasBeenRendered('l4218487435-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l4218487435-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4218487435-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4218487435-0');
} else {
    $response = \Livewire\Livewire::mount('citas.create-citas', ['id_exp' => $id_exp]);
    $html = $response->html();
    $_instance->logRenderedChild('l4218487435-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php /**PATH C:\Users\User\Desktop\sami2\sami\resources\views/livewire/citas/modal-crear.blade.php ENDPATH**/ ?>