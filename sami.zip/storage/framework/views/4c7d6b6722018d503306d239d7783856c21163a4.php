<div>
    <div class="modal-header">
        <h5 class="modal-title">Crear Receta</h5>
    </div>
    <div class="modal-body">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('recetas.create-recetas', ['id_exp' => $id_exp])->html();
} elseif ($_instance->childHasBeenRendered('l3276586148-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3276586148-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3276586148-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3276586148-0');
} else {
    $response = \Livewire\Livewire::mount('recetas.create-recetas', ['id_exp' => $id_exp]);
    $html = $response->html();
    $_instance->logRenderedChild('l3276586148-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php /**PATH C:\Users\User\Desktop\sami2\sami\resources\views/livewire/recetas/modal-crear.blade.php ENDPATH**/ ?>