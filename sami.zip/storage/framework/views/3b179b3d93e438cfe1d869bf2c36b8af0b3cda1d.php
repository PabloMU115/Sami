

<?php $__env->startSection('title', 'Expedientes'); ?>

<?php $__env->startSection('content'); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('expedientes.show-expedientes')->html();
} elseif ($_instance->childHasBeenRendered('R9DcQKU')) {
    $componentId = $_instance->getRenderedChildComponentId('R9DcQKU');
    $componentTag = $_instance->getRenderedChildComponentTagName('R9DcQKU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('R9DcQKU');
} else {
    $response = \Livewire\Livewire::mount('expedientes.show-expedientes');
    $html = $response->html();
    $_instance->logRenderedChild('R9DcQKU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\sami2\sami\resources\views/modulos/expedientes/index.blade.php ENDPATH**/ ?>