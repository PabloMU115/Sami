

<?php $__env->startSection('title', 'Citas'); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('citas.show-citas')->html();
} elseif ($_instance->childHasBeenRendered('eiYq83E')) {
    $componentId = $_instance->getRenderedChildComponentId('eiYq83E');
    $componentTag = $_instance->getRenderedChildComponentTagName('eiYq83E');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('eiYq83E');
} else {
    $response = \Livewire\Livewire::mount('citas.show-citas');
    $html = $response->html();
    $_instance->logRenderedChild('eiYq83E', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\sami2\sami\resources\views/modulos/citas/index.blade.php ENDPATH**/ ?>